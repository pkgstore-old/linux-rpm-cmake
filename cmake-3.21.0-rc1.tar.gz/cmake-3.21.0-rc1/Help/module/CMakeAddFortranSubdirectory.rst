.. cmake-module:: ../../Modules/CMakeAddFortranSubdirectory.cmake
